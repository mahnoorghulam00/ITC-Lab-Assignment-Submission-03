
#include <iostream>
using namespace std;
int main()
{
    char gradeLetter = 'S';
    char section = 'C';
    char initial = 'M';

    cout << "Grade Letter: " << gradeLetter << endl;
    cout << "Section: " << section << endl;
    cout << "Student Initial: " << initial << endl;
    cout << "ASCII code of gradeLetter: " << (int)gradeLetter << endl;
    cout << "Next letter: " << (char)(gradeLetter + 1) << endl;
    cout << "gradeLetter + 1 without conversion: " << gradeLetter + 1 << endl;
    cout << "'Z' - 'A': " << 'Z' - 'A' << endl;
    cout << "Letter three places after gradeLetter: "
      << (char)(gradeLetter + 3) << endl;
    return 0;
}
