﻿Build started at 8:27 PM...
1>------ Build started: Project: Project4, Configuration: Debug x64 ------
1>  project.4.cpp
1>  Project4.vcxproj -> C:\Users\Hp\source\repos\Project4\x64\Debug\Project4.exe
========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========
========== Build completed at 8:27 PM and took 01.916 seconds ==========
