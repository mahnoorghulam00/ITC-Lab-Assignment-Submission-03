
/*
Name: Mahnoor Ghulam Muhammad
Roll No: L1F26BSCS0091
section: A3
*/

#include <iostream>
using namespace std;

int main()
{
    char letter, symbol;
    cout << "Enter a letter: ";
    cin >> letter;
    cout << "Enter a symbol: ";
    cin >> symbol;
    cout << "the letter is: " << letter << endl;
    cout << "the symbol is: " << symbol << endl;

    return 0;
}
