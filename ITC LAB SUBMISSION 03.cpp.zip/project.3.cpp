#include <iostream>
using namespace std;
int main()
{
    char firstInitial, middleInitial, lastInitial;

    cout << "Enter your first initial: ";
    cin >> firstInitial;
    cout << "Enter your middle initial: ";
    cin >> middleInitial;
    cout << "Enter your last initial: ";
    cin >> lastInitial;
    cout << "Badge: " << firstInitial << "."
          << middleInitial << "."
        << lastInitial << "." << endl;

    /*
    Experiment 1:
    When we type M F K on one line, cin >> reads
    M, F, and K separately because it skips spaces.
    When we type MFK at the first prompt, only M is
    read. The next prompts wait for F and K.

    Experiment 2:
    cin >> does not care whether letters are entered
    on one line or separate lines. It skips whitespace.
    */

    return 0;
}
